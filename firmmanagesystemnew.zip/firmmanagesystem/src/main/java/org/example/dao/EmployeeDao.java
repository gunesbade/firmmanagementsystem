package org.example.dao;

import org.example.entity.Employee;
import org.example.exception.EmployeeException;

import java.util.List;

/**
 * Interface defining database operations for employees.
 */
public interface EmployeeDao {

    // Authenticates an employee
    Employee loginEmployee(String username, String password) throws EmployeeException;

    // Retrieves an employee's profile by ID
    Employee getProfile(int employeeId) throws EmployeeException;

    // Updates an employee's profile (specific fields)
    void updateProfile(int employeeId, String phoneNo, String email, String password) throws EmployeeException;

    // Retrieves all employees
    List<Employee> getAllEmployees() throws EmployeeException;

    // Retrieves employees by their role
    List<Employee> getEmployeesByRole(String role) throws EmployeeException;

    // Retrieves an employee by username
    Employee getEmployeeByUsername(String username) throws EmployeeException;

    // Updates an employee's non-profile fields
    void updateEmployeeNonProfile(String username, String phoneNo, String email) throws EmployeeException;

    // Adds a new employee
    void hireEmployee(Employee employee) throws EmployeeException;

    // Removes an employee by ID
    void fireEmployee(int employeeId) throws EmployeeException;

    // Removes an employee by username
    void fireEmployee(String username) throws EmployeeException;
}
