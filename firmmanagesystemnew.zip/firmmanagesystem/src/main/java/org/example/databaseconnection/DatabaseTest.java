import java.sql.Connection;
import org.example.databaseconnection.DatabaseConnection;

public class DatabaseTest {
    public static void main(String[] args) {
        Connection conn = DatabaseConnection.provideConnection();
        if (conn != null) {
            System.out.println("Database connection successful!");
        } else {
            System.out.println("Database connection failed!");
        }
    }
}
