package org.example.utils;

/**
 * Utility class providing helper methods for console operations.
 */
public class ConsoleUtils {

    /**
     * Clears the console screen.
     * <p>
     * This method uses ANSI escape codes to clear the console and reset the cursor to the top-left corner.
     * Note: This method may not work on all console environments (e.g., Windows default Command Prompt without ANSI support).
     */
    public static void clearConsole() {
        // ANSI escape sequence to clear the screen and move the cursor to the top-left corner.
        System.out.print("\033[H\033[2J");
        System.out.flush(); // Ensures that the command is sent immediately to the output stream.
    }
}