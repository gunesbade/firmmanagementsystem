package org.example.databaseconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/firmmanagesystem";
    private static final String USER = "root"; // Veritabanı kullanıcı adı
    private static final String PASSWORD = "$Bade1907"; // Veritabanı şifresi

    /**
     * Veritabanı bağlantısı sağlar.
     *
     * @return Connection nesnesi
     */
    public static Connection provideConnection() {
        Connection conn = null;

        try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            System.out.println("Database connection failed: " + e.getMessage());
            e.printStackTrace();
        }

        return conn;
    }
}
