package org.example.utils;

import java.util.Arrays;

/**
 * A utility class that provides implementations of various sorting algorithms.
 * It includes methods for Radix Sort, Shell Sort, Heap Sort, and Insertion Sort.
 */
public class SortingAlgorithms {

    /**
     * Implements the Radix Sort algorithm to sort an array of integers.
     * Radix Sort works by sorting the input numbers based on their individual digits, starting from the least significant digit.
     * The algorithm uses Counting Sort as a subroutine to sort the elements at each digit level.
     *
     * @param arr the array to be sorted
     * @param n the length of the array
     */
    // Public because it will be called from outside
    public static void radixSort(int[] arr, int n) {
        int max = Arrays.stream(arr).max().orElse(0);
        int min = Arrays.stream(arr).min().orElse(0);
        int offset = Math.abs(min);

        // Adjust all numbers by the offset to handle negative values
        for (int i = 0; i < n; i++) {
            arr[i] += offset;
        }

        // Apply Counting Sort for each digit starting from the least significant digit
        for (int exp = 1; (max + offset) / exp > 0; exp *= 10) {
            countSort(arr, n, exp);  // Calling private method countSort
        }

        // Restore the original values by removing the offset
        for (int i = 0; i < n; i++) {
            arr[i] -= offset;
        }
    }

    /**
     * Implements the Counting Sort algorithm, used as a subroutine in Radix Sort.
     * This method sorts the input array based on a particular digit represented by the exp parameter.
     *
     * @param arr the array to be sorted
     * @param n the length of the array
     * @param exp the current digit level to sort (1 for least significant digit, 10 for next, etc.)
     */
    // Private because it is only used inside radixSort
    private static void countSort(int[] arr, int n, int exp) {
        int[] output = new int[n];
        int[] count = new int[10];
        Arrays.fill(count, 0);

        // Calculate offset for negative numbers
        int min = Arrays.stream(arr).min().orElse(0);
        int offset = Math.abs(min);

        // Count occurrences of digits at the current digit place
        for (int i = 0; i < n; i++) {
            count[((arr[i] + offset) / exp) % 10]++;
        }

        // Calculate position of each element in the output array
        for (int i = 1; i < 10; i++) {
            count[i] += count[i - 1];
        }

        // Build the output array using the positions calculated
        for (int i = n - 1; i >= 0; i--) {
            output[count[((arr[i] + offset) / exp) % 10] - 1] = arr[i];
            count[((arr[i] + offset) / exp) % 10]--;
        }

        // Copy the sorted output back to the original array
        System.arraycopy(output, 0, arr, 0, n);
    }

    /**
     * Implements the Shell Sort algorithm to sort an array of integers.
     * Shell Sort is an optimization of Insertion Sort, where elements are compared and swapped at a gap distance
     * that decreases progressively until the gap becomes 1 (final Insertion Sort).
     *
     * @param arr the array to be sorted
     */
    // Public because it will be called from outside
    public static void shellSort(int[] arr) {
        int n = arr.length;

        // Start with a gap size of n/2 and progressively reduce it
        for (int gap = n / 2; gap > 0; gap /= 2) {
            // Perform insertion sort on subarrays with the given gap
            for (int i = gap; i < n; i++) {
                int temp = arr[i];
                int j;
                // Insert the element in the sorted part of the array
                for (j = i; j >= gap && arr[j - gap] > temp; j -= gap) {
                    arr[j] = arr[j - gap];
                }
                arr[j] = temp;
            }
        }
    }

    /**
     * Implements the Heap Sort algorithm to sort an array of integers.
     * Heap Sort first builds a max-heap and then repeatedly swaps the root of the heap (largest element) with the last element
     * and reduces the heap size until the array is sorted.
     *
     * @param arr the array to be sorted
     */
    // Public because it will be called from outside
    public static void heapSort(int[] arr) {
        int n = arr.length;

        // Build the max heap
        for (int i = n / 2 - 1; i >= 0; i--) {
            heapify(arr, n, i); // Calling private method heapify
        }

        // Extract elements from the heap one by one
        for (int i = n - 1; i > 0; i--) {
            // Swap the root (largest element) with the last element
            int temp = arr[0];
            arr[0] = arr[i];
            arr[i] = temp;

            // Rebuild the heap with the reduced size
            heapify(arr, i, 0); // Calling private method heapify
        }
    }

    /**
     * Maintains the max-heap property for a subtree rooted at index i.
     * This method is used during heap sort to rebuild the heap after each swap.
     *
     * @param arr the array representing the heap
     * @param n the size of the heap
     * @param i the index of the subtree root
     */
    // Private because it is only used inside heapSort
    private static void heapify(int[] arr, int n, int i) {
        int largest = i;
        int l = 2 * i + 1;  // Left child
        int r = 2 * i + 2;  // Right child

        // Compare with left child
        if (l < n && arr[l] > arr[largest]) {
            largest = l;
        }

        // Compare with right child
        if (r < n && arr[r] > arr[largest]) {
            largest = r;
        }

        // Swap if needed and recursively heapify the affected subtree
        if (largest != i) {
            int temp = arr[i];
            arr[i] = arr[largest];
            arr[largest] = temp;
            heapify(arr, n, largest); // Recursive call
        }
    }

    /**
     * Implements the Insertion Sort algorithm to sort an array of integers.
     * Insertion Sort iterates through the array and inserts each element into its correct position in the sorted portion
     * of the array by shifting elements to the right.
     *
     * @param arr the array to be sorted
     */
    // Public because it will be called from outside
    public static void insertionSort(int[] arr) {
        int n = arr.length;

        // Iterate through the array and insert each element into the sorted portion
        for (int i = 1; i < n; i++) {
            int key = arr[i];
            int j = i - 1;
            // Shift elements to the right to make room for the key element
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
    }
}