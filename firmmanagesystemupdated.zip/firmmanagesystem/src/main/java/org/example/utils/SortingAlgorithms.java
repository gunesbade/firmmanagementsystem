package org.example.utils;

import java.util.Arrays;

public class SortingAlgorithms {

    // Public çünkü dışarıdan çağrılacak
    public static void radixSort(int[] arr, int n) {
        int max = Arrays.stream(arr).max().orElse(0);
        int min = Arrays.stream(arr).min().orElse(0);
        int offset = Math.abs(min);

        for (int i = 0; i < n; i++) {
            arr[i] += offset;
        }

        for (int exp = 1; (max + offset) / exp > 0; exp *= 10) {
            countSort(arr, n, exp);  // Private metot çağrılıyor
        }

        for (int i = 0; i < n; i++) {
            arr[i] -= offset;
        }
    }

    // Private çünkü sadece radixSort içinde kullanılıyor
    private static void countSort(int[] arr, int n, int exp) {
        int[] output = new int[n];
        int[] count = new int[10];
        Arrays.fill(count, 0);

        // Negatif sayılar için offset hesaplayın
        int min = Arrays.stream(arr).min().orElse(0);
        int offset = Math.abs(min);

        // Sayıları pozitif hale getir ve say
        for (int i = 0; i < n; i++) {
            count[((arr[i] + offset) / exp) % 10]++;
        }

        // Pozisyonları hesapla
        for (int i = 1; i < 10; i++) {
            count[i] += count[i - 1];
        }

        // Çıkış dizisini oluştur
        for (int i = n - 1; i >= 0; i--) {
            output[count[((arr[i] + offset) / exp) % 10] - 1] = arr[i];
            count[((arr[i] + offset) / exp) % 10]--;
        }

        // Orijinal diziyi güncelle
        System.arraycopy(output, 0, arr, 0, n);
    }

    // Public çünkü dışarıdan çağrılacak
    public static void shellSort(int[] arr) {
        int n = arr.length;
        for (int gap = n / 2; gap > 0; gap /= 2) {
            for (int i = gap; i < n; i++) {
                int temp = arr[i];
                int j;
                for (j = i; j >= gap && arr[j - gap] > temp; j -= gap) {
                    arr[j] = arr[j - gap];
                }
                arr[j] = temp;
            }
        }
    }

    // Public çünkü dışarıdan çağrılacak
    public static void heapSort(int[] arr) {
        int n = arr.length;

        for (int i = n / 2 - 1; i >= 0; i--) {
            heapify(arr, n, i); // Private metot çağrılıyor
        }

        for (int i = n - 1; i > 0; i--) {
            int temp = arr[0];
            arr[0] = arr[i];
            arr[i] = temp;

            heapify(arr, i, 0); // Private metot çağrılıyor
        }
    }

    // Private çünkü sadece heapSort içinde kullanılıyor
    private static void heapify(int[] arr, int n, int i) {
        int largest = i;
        int l = 2 * i + 1;
        int r = 2 * i + 2;

        if (l < n && arr[l] > arr[largest]) {
            largest = l;
        }

        if (r < n && arr[r] > arr[largest]) {
            largest = r;
        }

        if (largest != i) {
            int temp = arr[i];
            arr[i] = arr[largest];
            arr[largest] = temp;
            heapify(arr, n, largest); // Recursive çağrı
        }
    }

    // Public çünkü dışarıdan çağrılacak
    public static void insertionSort(int[] arr) {
        int n = arr.length;
        for (int i = 1; i < n; i++) {
            int key = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
    }
}
