package org.example.menus;

import org.example.dao.EmployeeDao;
import org.example.dao.EmployeeDaoImplementation;
import org.example.entity.Employee;
import org.example.exception.EmployeeException;
import org.example.utils.SortingAlgorithms;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import java.util.Random;
import java.util.Arrays;

/**
 * Manager-specific menu with CRUD operations and algorithm functionalities.
 */
public class ManagerMenu {

    public static void display(Scanner scanner, int managerId) {
        boolean isRunning = true;

        while (isRunning) {
            System.out.println("\n=== Manager Menu ===");
            System.out.println("1. Update Your Profile");
            System.out.println("2. View All Employees");
            System.out.println("3. View Employees by Role");
            System.out.println("4. View Employee by Username");
            System.out.println("5. Update Employee Non-Profile Fields");
            System.out.println("6. Hire Employee");
            System.out.println("7. Fire Employee");
            System.out.println("8. Algorithms");
            System.out.println("9. Logout");
            System.out.print("Choose an option: ");

            int choice = -1; // Default invalid choice
            try {
                String input = scanner.nextLine();
                choice = Integer.parseInt(input); // Seçim parse ediliyor
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number between 1 and 9.");
                continue; // Geçerli bir giriş beklemek için döngüyü yeniden başlat
            }

            switch (choice) {
                case 1 -> updateProfile(scanner, managerId);
                case 2 -> viewAllEmployees();
                case 3 -> viewEmployeesByRole(scanner);
                case 4 -> viewEmployeeByUsername(scanner);
                case 5 -> updateEmployeeNonProfileFields(scanner);
                case 6 -> hireEmployee(scanner);
                case 7 -> fireEmployee(scanner, managerId);
                case 8 -> executeSortingAlgorithms(scanner);
                case 9 -> {
                    System.out.println("Logging out...");
                    isRunning = false;
                }
                default -> System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    private static void updateProfile(Scanner scanner, int managerId) {
        System.out.println("\n--- Update Profile ---");

        EmployeeDao dao = new EmployeeDaoImplementation();
        Employee currentProfile;
        try {
            currentProfile = dao.getProfile(managerId);
        } catch (EmployeeException e) {
            System.out.println("Failed to fetch current profile: " + e.getMessage());
            return;
        }

        String phoneNo;
        while (true) {
            System.out.print("Enter new phone number (or press Enter to keep current): ");
            phoneNo = scanner.nextLine();
            if (phoneNo.isEmpty()) {
                phoneNo = currentProfile.getPhoneNo();
                break;
            }
            if (phoneNo.matches("\\d+")) break; // Check if phoneNo contains only digits
            System.out.println("Invalid phone number. Please enter numeric values only.");
        }

        System.out.print("Enter new email (or press Enter to keep current): ");
        String email = scanner.nextLine();
        if (email.isEmpty()) email = currentProfile.getEmail();

        System.out.print("Enter new password (or press Enter to keep current): ");
        String password = scanner.nextLine();
        if (password.isEmpty()) password = currentProfile.getPassword();

        if (phoneNo.equals(currentProfile.getPhoneNo()) &&
                email.equals(currentProfile.getEmail()) &&
                password.equals(currentProfile.getPassword())) {
            System.out.println("No updates were made. Please update at least one field.");
            return;
        }

        try {
            dao.updateProfile(managerId, phoneNo, email, password);
            System.out.println("Profile updated successfully!");
        } catch (EmployeeException e) {
            System.out.println("Failed to update profile: " + e.getMessage());
        }
    }

    private static void updateEmployeeNonProfileFields(Scanner scanner) {
        System.out.println("\n--- Update Employee Non-Profile Fields ---");

        System.out.print("Enter username of the employee: ");
        String username = scanner.nextLine();

        String phoneNo;
        while (true) {
            System.out.print("Enter new phone number (or press Enter to skip): ");
            phoneNo = scanner.nextLine();
            if (phoneNo.isEmpty() || phoneNo.matches("\\d+")) break; // Allow skip or numeric values
            System.out.println("Invalid phone number. Please enter numeric values only.");
        }

        System.out.print("Enter new email (or press Enter to skip): ");
        String email = scanner.nextLine();

        try {
            EmployeeDao dao = new EmployeeDaoImplementation();
            Employee employee = dao.getEmployeeByUsername(username);

            if (employee == null) {
                System.out.println("Employee not found with the given username.");
                return;
            }

            // Retain old values if the user chooses to skip any field
            if (phoneNo.isEmpty()) phoneNo = employee.getPhoneNo();
            if (email.isEmpty()) email = employee.getEmail();

            // Check if no updates were made
            if (phoneNo.equals(employee.getPhoneNo()) && email.equals(employee.getEmail())) {
                System.out.println("No updates were made. Existing values were kept.");
                return;
            }

            // Perform the update
            boolean success = dao.updateEmployeeNonProfile(username, phoneNo, email);

            if (success) {
                System.out.println("Employee details updated successfully!");
            } else {
                System.out.println("Failed to update employee details.");
            }
        } catch (EmployeeException e) {
            System.out.println("Error updating employee details: " + e.getMessage());
        }
    }


    private static void viewAllEmployees() {
        System.out.println("\n--- View All Employees ---");
        try {
            EmployeeDao dao = new EmployeeDaoImplementation();
            List<Employee> employees = dao.getAllEmployees();
            if (employees.isEmpty()) {
                System.out.println("No employees found.");
            } else {
                employees.forEach(System.out::println);
            }
        } catch (EmployeeException e) {
            System.out.println("Error retrieving employees: " + e.getMessage());
        }
    }

    private static void viewEmployeesByRole(Scanner scanner) {
        System.out.println("\n--- View Employees by Role ---");
        System.out.print("Enter role (e.g., manager, engineer, technician, intern): ");
        String role = scanner.nextLine();

        try {
            EmployeeDao dao = new EmployeeDaoImplementation();
            List<Employee> employees = dao.getEmployeesByRole(role);
            if (employees == null || employees.isEmpty()) {
                System.out.println("No employees found for the role: " + role);
            } else {
                employees.forEach(System.out::println);
            }
        } catch (EmployeeException e) {
            System.out.println("Error retrieving employees by role: " + e.getMessage());
        }
    }

    private static void viewEmployeeByUsername(Scanner scanner) {
        System.out.println("\n--- View Employee by Username ---");
        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        try {
            EmployeeDao dao = new EmployeeDaoImplementation();
            Employee employee = dao.getEmployeeByUsername(username);
            if (employee == null) {
                System.out.println("No employee found with the username: " + username);
            } else {
                System.out.println(employee);
            }
        } catch (EmployeeException e) {
            System.out.println("Error retrieving employee: " + e.getMessage());
        }
    }

    private static void hireEmployee(Scanner scanner) {
        System.out.println("\n--- Hire Employee ---");
        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        // Random şifre oluşturma
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$%";
        Random random = new Random();
        StringBuilder passwordBuilder = new StringBuilder();
        int length = 8 + random.nextInt(5); // 8 ile 12 arasında uzunluk
        for (int i = 0; i < length; i++) {
            passwordBuilder.append(characters.charAt(random.nextInt(characters.length())));
        }
        String defaultPassword = passwordBuilder.toString();

        System.out.print("Enter role (e.g., manager, engineer, technician, intern): ");
        String role = scanner.nextLine();

        System.out.print("Enter name: ");
        String name = scanner.nextLine();

        System.out.print("Enter surname: ");
        String surname = scanner.nextLine();

        // Telefon numarası zorunlu ve numerik olmalı
        String phoneNo;
        while (true) {
            System.out.print("Enter phone number: ");
            phoneNo = scanner.nextLine();
            if (phoneNo.matches("\\d+")) break;
            System.out.println("Invalid phone number. Please enter numeric values only.");
        }

        // Email zorunlu ve formatı kontrol edilecek
        String email;
        while (true) {
            System.out.print("Enter email: ");
            email = scanner.nextLine();
            if (!email.isEmpty() && email.contains("@") && email.contains(".")) break;
            System.out.println("Invalid email. Please enter a valid email address.");
        }

        // Doğum tarihi ve başlangıç tarihi format kontrolü
        String dateOfBirth;
        while (true) {
            System.out.print("Enter date of birth (YYYY-MM-DD): ");
            dateOfBirth = scanner.nextLine();
            if (dateOfBirth.matches("\\d{4}-\\d{2}-\\d{2}")) break;
            System.out.println("Invalid date format. Please enter in YYYY-MM-DD format.");
        }

        String dateOfStart;
        while (true) {
            System.out.print("Enter date of start (YYYY-MM-DD): ");
            dateOfStart = scanner.nextLine();
            if (dateOfStart.matches("\\d{4}-\\d{2}-\\d{2}")) break;
            System.out.println("Invalid date format. Please enter in YYYY-MM-DD format.");
        }

        try {
            EmployeeDao dao = new EmployeeDaoImplementation();

            // Yeni employee nesnesi oluştur
            Employee employee = new Employee(
                    0,
                    username,
                    defaultPassword, // Default şifre burada kullanılıyor
                    role,
                    name,
                    surname,
                    phoneNo,
                    LocalDate.parse(dateOfBirth),
                    LocalDate.parse(dateOfStart),
                    email
            );

            // Hire employee
            dao.hireEmployee(employee);
            System.out.println("Employee hired successfully with default password: " + defaultPassword);
        } catch (EmployeeException e) {
            System.out.println("Failed to hire employee: " + e.getMessage());
        }
    }



    private static void fireEmployee(Scanner scanner, int managerId) {
        System.out.println("\n--- Fire Employee ---");
        System.out.print("Enter username of the employee to fire: ");
        String username = scanner.nextLine();

        try {
            EmployeeDao dao = new EmployeeDaoImplementation();
            Employee employee = dao.getEmployeeByUsername(username);

            if (employee == null) {
                System.out.println("No employee found with the given username.");
                return;
            }

            // Prevent the manager from firing themselves
            if (employee.getEmployeeId() == managerId) {
                System.out.println("Action denied: Managers are not permitted to remove their own accounts.");
                return;
            }

            dao.fireEmployee(username); // Fire the employee
            System.out.println("Employee fired successfully!");
        } catch (EmployeeException e) {
            System.out.println("Failed to fire employee: " + e.getMessage());
        }
    }

    private static void executeSortingAlgorithms(Scanner scanner) {
        System.out.println("\n--- Sorting Algorithms ---");

        int datasetSize = 0;

        // Dataset boyutunu alırken hata yakalama
        while (true) {
            try {
                System.out.print("Enter dataset size (1000 to 10000): ");
                datasetSize = scanner.nextInt();
                scanner.nextLine(); // Satır sonu karakterini temizle

                if (datasetSize < 1000 || datasetSize > 10000) {
                    System.out.println("Invalid dataset size. Please enter a value between 1000 and 10000.");
                    continue;
                }
                break; // Geçerli bir değer girildiğinde döngüden çık
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a numeric value between 1000 and 10000.");
                scanner.nextLine(); // Hatalı girdiyi temizle
            }
        }

        // Generate a random dataset of integers within the range [-10,000, 10,000]
        int[] data = new Random().ints(datasetSize, -10000, 10000).toArray();
        System.out.println("Dataset generated.");

        // Create separate copies of the dataset for each sorting algorithm
        int[] radixData = Arrays.copyOf(data, data.length);
        int[] shellData = Arrays.copyOf(data, data.length);
        int[] heapData = Arrays.copyOf(data, data.length);
        int[] insertionData = Arrays.copyOf(data, data.length);
        int[] expected = Arrays.copyOf(data, data.length);

        // Use Java's built-in `Arrays.sort` method to produce the correct sorted result
        Arrays.sort(expected);

        // Table header
        System.out.printf("\n%-20s %10s %10s\n", "Algorithm", "Time (ms)", "Status");
        System.out.println("------------------------------------------");


        // Execute and verify Radix Sort
        long startTime = System.nanoTime();
        SortingAlgorithms.radixSort(radixData, radixData.length);
        long endTime = System.nanoTime();
        System.out.println("Radix Sort time (ms): " + (endTime - startTime) / 1_000_000);
        if (!Arrays.equals(radixData, expected)) {
            System.out.println("Radix Sort failed.");
        } else {
            System.out.println("Radix Sort verified.");
        }

        // Execute and verify Shell Sort
        startTime = System.nanoTime();
        SortingAlgorithms.shellSort(shellData);
        endTime = System.nanoTime();
        System.out.println("Shell Sort time (ms): " + (endTime - startTime) / 1_000_000);
        if (!Arrays.equals(shellData, expected)) {
            System.out.println("Shell Sort failed.");
        } else {
            System.out.println("Shell Sort verified.");
        }

        // Execute and verify Heap Sort
        startTime = System.nanoTime();
        SortingAlgorithms.heapSort(heapData);
        endTime = System.nanoTime();
        System.out.println("Heap Sort time (ms): " + (endTime - startTime) / 1_000_000);
        if (!Arrays.equals(heapData, expected)) {
            System.out.println("Heap Sort failed.");
        } else {
            System.out.println("Heap Sort verified.");
        }

        // Execute and verify Insertion Sort
        startTime = System.nanoTime();
        SortingAlgorithms.insertionSort(insertionData);

        endTime = System.nanoTime();
        System.out.println("Insertion Sort time (ms): " + (endTime - startTime) / 1_000_000);
        if (!Arrays.equals(insertionData, expected)) {
            System.out.println("Insertion Sort failed.");
        } else {
            System.out.println("Insertion Sort verified.");
        }

        // Kullanıcı onayı ile menüye dönüş
        System.out.print("\nPress 'Enter' to return to the Manager menu...");
        scanner.nextLine();
    }

}

