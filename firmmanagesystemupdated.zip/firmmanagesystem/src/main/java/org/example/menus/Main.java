package org.example.menus;

import org.example.dao.EmployeeDao;
import org.example.dao.EmployeeDaoImplementation;
import org.example.entity.Employee;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

/**
 * Main menu class for the Firm Management System.
 */
public class Main {

    public static void main(String[] args) {
        renderASCIIArt(); // Display the ASCII art at the top

        Scanner scanner = new Scanner(System.in);
        EmployeeDao dao = new EmployeeDaoImplementation();

        boolean isRunning = true;

        // Main menu loop
        while (isRunning) {
            System.out.println("\n=== Welcome to the Firm Management System ===");
            System.out.println("1. Login");
            System.out.println("2. Register");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");

            int choice = -1; // Default invalid choice
            try {
                // Get user input and parse to integer
                String input = scanner.nextLine();
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number between 1 and 3.");
                continue; // Restart the loop for valid input
            }

            // Handle user choices
            switch (choice) {
                case 1 -> login(scanner, dao);
                case 2 -> register(scanner, dao);
                case 3 -> {
                    System.out.println("Exiting the system...");
                    isRunning = false; // Exit the loop
                }
                default -> System.out.println("Invalid option. Please enter a number between 1 and 3.");
            }
        }
    }

    /**
     * Login process for the system.
     *
     * @param scanner Scanner instance for input.
     * @param dao     Data access object for employee operations.
     */
    private static void login(Scanner scanner, EmployeeDao dao) {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        try {
            Employee emp = dao.loginEmployee(username, password);

            if (emp != null) {
                System.out.println("\nLogin Successful!");
                System.out.println("Welcome, " + emp.getName() + " " + emp.getSurname() + "!");
                System.out.println("Role: " + emp.getRole());

                // Redirect user to the appropriate menu
                if ("manager".equalsIgnoreCase(emp.getRole())) {
                    ManagerMenu.display(scanner, emp.getEmployeeId()); // Manager-specific menu
                } else {
                    RegularMenu.display(scanner, emp.getEmployeeId()); // Regular employee menu
                }
            } else {
                System.out.println("Invalid username or password.");
            }
        } catch (Exception e) {
            System.out.println("Login failed: " + e.getMessage());
        }
    }

    /**
     * Registration process for the system.
     *
     * @param scanner Scanner instance for input.
     * @param dao     Data access object for employee operations.
     */
    private static void register(Scanner scanner, EmployeeDao dao) {
        System.out.println("\n--- Register ---");
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        System.out.print("Enter role (manager, engineer, technician, intern): ");
        String role = scanner.nextLine();
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter surname: ");
        String surname = scanner.nextLine();
        System.out.print("Enter phone number: ");
        String phoneNo = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();

        try {
            System.out.print("Enter date of birth (YYYY-MM-DD): ");
            String dateOfBirth = scanner.nextLine();
            LocalDate parsedDateOfBirth = LocalDate.parse(dateOfBirth); // Validate date

            System.out.print("Enter date of start (YYYY-MM-DD): ");
            String dateOfStart = scanner.nextLine();
            LocalDate parsedDateOfStart = LocalDate.parse(dateOfStart); // Validate date

            Employee newEmployee = new Employee(
                    0,
                    username,
                    password,
                    role,
                    name,
                    surname,
                    phoneNo,
                    parsedDateOfBirth,
                    parsedDateOfStart,
                    email
            );

            dao.hireEmployee(newEmployee);
            System.out.println("Registration successful!");
        } catch (DateTimeParseException e) {
            System.out.println("Invalid date format. Please use YYYY-MM-DD.");
        } catch (Exception e) {
            System.out.println("Registration failed: " + e.getMessage());
        }
    }

    /**
     * Renders the "WELCOME" ASCII art at the top of the console.
     */
    public static void renderASCIIArt() {
        int width = 200; // Width setting
        int height = 10; // Height setting

        // Create the image
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics g = image.getGraphics();
        g.setFont(new Font("SansSerif", Font.BOLD, 14)); // Font setting

        // Enable text anti-aliasing for smoother rendering
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        // Draw "WELCOME" text
        g2.drawString("WELCOME", 10, 11);

        // ANSI escape code for green color
        final String GREEN = "\u001B[32m";
        final String RESET = "\u001B[0m"; // Reset color

        // Loop through each pixel row
        for (int y = 0; y < height; y++) {
            StringBuilder builder = new StringBuilder();

            // Loop through each pixel column
            for (int x = 0; x < width; x++) {
                // Append space for black pixels, green @ for non-black pixels
                if (image.getRGB(x, y) == -16777216) {
                    builder.append(" ");
                } else {
                    builder.append(GREEN).append("@").append(RESET); // Green @ symbol
                }
            }
            // Print the line to console
            System.out.println(builder.toString());
        }
    }
}
