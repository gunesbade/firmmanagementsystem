package org.example.dao;

import org.example.entity.Employee;
import org.example.exception.EmployeeException;

import java.util.List;

/**
 * Interface defining database operations for employees.
 * Provides methods for authentication, profile management,
 * employee management, and data validation.
 */
public interface EmployeeDao {

    /**
     * Authenticates an employee using their username and password.
     *
     * @param username The username of the employee.
     * @param password The password of the employee.
     * @return The authenticated Employee object.
     * @throws EmployeeException If authentication fails or an error occurs.
     */
    Employee loginEmployee(String username, String password) throws EmployeeException;

    /**
     * Retrieves an employee's profile based on their unique ID.
     *
     * @param employeeId The unique ID of the employee.
     * @return The Employee object representing the profile.
     * @throws EmployeeException If the employee is not found or an error occurs.
     */
    Employee getProfile(int employeeId) throws EmployeeException;

    /**
     * Retrieves an employee based on their unique ID.
     *
     * @param employeeId The unique ID of the employee.
     * @return The Employee object.
     * @throws EmployeeException If the employee is not found or an error occurs.
     */
    Employee getEmployeeById(int employeeId) throws EmployeeException;

    /**
     * Updates specific fields of an employee's profile.
     *
     * @param employeeId The unique ID of the employee.
     * @param phoneNo    The new phone number of the employee.
     * @param email      The new email address of the employee.
     * @param password   The new password of the employee.
     * @throws EmployeeException If the update fails or an error occurs.
     */
    void updateProfile(int employeeId, String phoneNo, String email, String password) throws EmployeeException;

    /**
     * Retrieves a list of all employees.
     *
     * @return A list of Employee objects.
     * @throws EmployeeException If an error occurs while retrieving employees.
     */
    List<Employee> getAllEmployees() throws EmployeeException;

    /**
     * Retrieves a list of employees by their role.
     *
     * @param role The role of the employees to retrieve (e.g., "manager", "technician").
     * @return A list of Employee objects matching the role.
     * @throws EmployeeException If an error occurs or no employees are found.
     */
    List<Employee> getEmployeesByRole(String role) throws EmployeeException;

    /**
     * Retrieves an employee by their username.
     *
     * @param username The username of the employee.
     * @return The Employee object.
     * @throws EmployeeException If the employee is not found or an error occurs.
     */
    Employee getEmployeeByUsername(String username) throws EmployeeException;

    /**
     * Updates an employee's non-profile fields (phone number and email) by their ID.
     *
     * @param employeeId The unique ID of the employee.
     * @param phoneNo    The new phone number.
     * @param email      The new email address.
     * @return True if the update is successful, false otherwise.
     * @throws EmployeeException If the update fails or an error occurs.
     */
    boolean updateEmployeeNonProfile(int employeeId, String phoneNo, String email) throws EmployeeException;

    /**
     * Updates an employee's non-profile fields (phone number, email) by their username.
     *
     * @param username The username of the employee.
     * @param phoneNo  The new phone number.
     * @param email    The new email address.
     * @return True if the update is successful, false otherwise.
     * @throws EmployeeException If the update fails or an error occurs.
     */
    boolean updateEmployeeNonProfile(String username, String phoneNo, String email) throws EmployeeException;

    /**
     * Checks whether a phone number or email is unique across employees,
     * excluding a specific employee ID.
     *
     * @param phoneNo          The phone number to check.
     * @param email            The email address to check.
     * @param excludeEmployeeId The ID of the employee to exclude from the check.
     * @return True if the phone number and email are unique, false otherwise.
     * @throws EmployeeException If an error occurs during the validation.
     */
    boolean isPhoneNoOrEmailUnique(String phoneNo, String email, int excludeEmployeeId) throws EmployeeException;

    /**
     * Hires a new employee by adding them to the system.
     *
     * @param employee The Employee object containing the new employee's details.
     * @throws EmployeeException If hiring fails or an error occurs.
     */
    void hireEmployee(Employee employee) throws EmployeeException;

    /**
     * Removes an employee from the system based on their unique ID.
     *
     * @param employeeId The unique ID of the employee to be removed.
     * @throws EmployeeException If removal fails or the employee is not found.
     */
    void fireEmployee(int employeeId) throws EmployeeException;

    /**
     * Updates an employee's non-profile fields (phone number, email, and password)
     * by their username.
     *
     * @param username The username of the employee.
     * @param phoneNo  The new phone number.
     * @param email    The new email address.
     * @param password The new password.
     * @return True if the update is successful, false otherwise.
     * @throws EmployeeException If the update fails or an error occurs.
     */
    boolean updateEmployeeNonProfile(String username, String phoneNo, String email, String password) throws EmployeeException;

    /**
     * Removes an employee from the system based on their username.
     *
     * @param username The username of the employee to be removed.
     * @throws EmployeeException If removal fails or the employee is not found.
     */
    void fireEmployee(String username) throws EmployeeException;

    /**
     * Checks if a specific field (e.g., username, email, phone number) is unique.
     *
     * @param field The field name to check (e.g., "username", "email").
     * @param value The value of the field to check.
     * @return True if the field is unique, false otherwise.
     * @throws EmployeeException If an error occurs during the validation.
     */
    boolean isUniqueField(String field, String value) throws EmployeeException;

    /**
     * Validates the format of a date string.
     *
     * @param date The date string to validate.
     * @return True if the date format is valid, false otherwise.
     * @throws EmployeeException If an error occurs during the validation.
     */
    boolean isValidDateFormat(String date) throws EmployeeException;

}
