package org.example.dao;

import org.example.databaseconnection.DatabaseConnection;
import org.example.entity.Employee;
import org.example.exception.EmployeeException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDaoImplementation implements EmployeeDao {

    @Override
    public Employee loginEmployee(String username, String password) throws EmployeeException {
        Employee emp = null;

        try (Connection conn = DatabaseConnection.provideConnection()) {
            String query = "SELECT * FROM employees WHERE username = ? AND password = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                emp = new Employee(
                        rs.getInt("employeeId"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role"),
                        rs.getString("name"),
                        rs.getString("surname"),
                        rs.getString("phoneNo"),
                        rs.getDate("dateOfBirth").toLocalDate(),
                        rs.getDate("dateOfStart").toLocalDate(),
                        rs.getString("email")
                );
            } else {
                throw new EmployeeException("Invalid username or password.");
            }
        } catch (Exception e) {
            throw new EmployeeException(" " + e.getMessage(), e);
        }

        return emp;
    }

    @Override
    public Employee getProfile(int employeeId) throws EmployeeException {
        Employee emp = null;

        try (Connection conn = DatabaseConnection.provideConnection()) {
            String query = "SELECT * FROM employees WHERE employeeId = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, employeeId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                emp = new Employee(
                        rs.getInt("employeeId"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role"),
                        rs.getString("name"),
                        rs.getString("surname"),
                        rs.getString("phoneNo"),
                        rs.getDate("dateOfBirth").toLocalDate(),
                        rs.getDate("dateOfStart").toLocalDate(),
                        rs.getString("email")
                );
            } else {
                throw new EmployeeException("Employee not found.");
            }
        } catch (Exception e) {
            throw new EmployeeException(" " + e.getMessage(), e);
        }

        return emp;
    }

    @Override
    public Employee getEmployeeById(int employeeId) throws EmployeeException {
        Employee emp = null;

        try (Connection conn = DatabaseConnection.provideConnection()) {
            String query = "SELECT * FROM employees WHERE employeeId = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, employeeId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                emp = new Employee(
                        rs.getInt("employeeId"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role"),
                        rs.getString("name"),
                        rs.getString("surname"),
                        rs.getString("phoneNo"),
                        rs.getDate("dateOfBirth").toLocalDate(),
                        rs.getDate("dateOfStart").toLocalDate(),
                        rs.getString("email")
                );
            } else {
                throw new EmployeeException("Employee not found with ID: " + employeeId);
            }
        } catch (Exception e) {
            throw new EmployeeException(" " + e.getMessage(), e);
        }

        return emp;
    }

    @Override
    public void updateProfile(int employeeId, String phoneNo, String email, String password) throws EmployeeException {
        try (Connection conn = DatabaseConnection.provideConnection()) {
            String query = "UPDATE employees SET phoneNo = ?, email = ?, password = ? WHERE employeeId = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, phoneNo);
            ps.setString(2, email);
            ps.setString(3, password);
            ps.setInt(4, employeeId);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected == 0) {
                throw new EmployeeException("Failed to update profile. Employee not found.");
            }
        } catch (Exception e) {
            throw new EmployeeException(" " + e.getMessage(), e);
        }
    }


    @Override
    public List<Employee> getAllEmployees() throws EmployeeException {
        List<Employee> employees = new ArrayList<>();

        try (Connection conn = DatabaseConnection.provideConnection()) {
            String query = "SELECT * FROM employees";
            PreparedStatement ps = conn.prepareStatement(query);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Employee emp = new Employee(
                        rs.getInt("employeeId"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role"),
                        rs.getString("name"),
                        rs.getString("surname"),
                        rs.getString("phoneNo"),
                        rs.getDate("dateOfBirth").toLocalDate(),
                        rs.getDate("dateOfStart").toLocalDate(),
                        rs.getString("email")
                );
                employees.add(emp);
            }
        } catch (Exception e) {
            throw new EmployeeException("Error: " + e.getMessage(), e);
        }

        return employees;
    }

    @Override
    public List<Employee> getEmployeesByRole(String role) throws EmployeeException {
        List<Employee> employees = new ArrayList<>();

        try (Connection conn = DatabaseConnection.provideConnection()) {
            String query = "SELECT * FROM employees WHERE role = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, role);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Employee emp = new Employee(
                        rs.getInt("employeeId"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role"),
                        rs.getString("name"),
                        rs.getString("surname"),
                        rs.getString("phoneNo"),
                        rs.getDate("dateOfBirth").toLocalDate(),
                        rs.getDate("dateOfStart").toLocalDate(),
                        rs.getString("email")
                );
                employees.add(emp);
            }
        } catch (Exception e) {
            throw new EmployeeException("Error while retrieving employees by role: " + e.getMessage(), e);
        }

        return employees;
    }

    @Override
    public Employee getEmployeeByUsername(String username) throws EmployeeException {
        Employee emp = null;

        try (Connection conn = DatabaseConnection.provideConnection()) {
            String query = "SELECT * FROM employees WHERE username = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, username);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                emp = new Employee(
                        rs.getInt("employeeId"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role"),
                        rs.getString("name"),
                        rs.getString("surname"),
                        rs.getString("phoneNo"),
                        rs.getDate("dateOfBirth").toLocalDate(),
                        rs.getDate("dateOfStart").toLocalDate(),
                        rs.getString("email")
                );
            }
        } catch (Exception e) {
            throw new EmployeeException("Error while retrieving employee by username: " + e.getMessage(), e);
        }

        return emp;
    }

    @Override
    public boolean updateEmployeeNonProfile(int employeeId, String phoneNo, String email) throws EmployeeException {
        return false;
    }

    @Override
    public boolean updateEmployeeNonProfile(String username, String phoneNo, String email) throws EmployeeException {
        try (Connection conn = DatabaseConnection.provideConnection()) {
            String query = "UPDATE employees SET phoneNo = ?, email = ? WHERE username = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, phoneNo);
            ps.setString(2, email);
            ps.setString(3, username);

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0; // Başarılıysa true döner
        } catch (Exception e) {
            throw new EmployeeException("Error while updating employee details: " + e.getMessage(), e);
        }
    }



    @Override
    public void hireEmployee(Employee employee) throws EmployeeException {
        if (employee.getEmail() == null || employee.getEmail().trim().isEmpty()) {
            throw new EmployeeException("Email is required to hire an employee.");
        }

        try {
            // Benzersiz alanları kontrol et
            if (!isUniqueField("username", employee.getUsername())) {
                throw new EmployeeException("Username already exists.");
            }
            if (!isUniqueField("email", employee.getEmail())) {
                throw new EmployeeException("Email already exists.");
            }
            if (!isUniqueField("phoneNo", employee.getPhoneNo())) {
                throw new EmployeeException("Phone number already exists.");
            }

            // Çalışanı ekle
            try (Connection conn = DatabaseConnection.provideConnection()) {
                String query = "INSERT INTO employees (username, password, role, name, surname, phoneNo, dateOfBirth, dateOfStart, email) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement ps = conn.prepareStatement(query);

                ps.setString(1, employee.getUsername());
                ps.setString(2, employee.getPassword());
                ps.setString(3, employee.getRole());
                ps.setString(4, employee.getName());
                ps.setString(5, employee.getSurname());
                ps.setString(6, employee.getPhoneNo());
                ps.setDate(7, java.sql.Date.valueOf(employee.getDateOfBirth()));
                ps.setDate(8, java.sql.Date.valueOf(employee.getDateOfStart()));
                ps.setString(9, employee.getEmail());

                int rowsAffected = ps.executeUpdate();
                if (rowsAffected == 0) {
                    throw new EmployeeException("Failed to hire employee.");
                }
            }
        } catch (EmployeeException e) {
            throw e; // Özel hata mesajını yeniden fırlat
        } catch (Exception e) {
            throw new EmployeeException("Error: " + e.getMessage(), e);
        }
    }

    @Override
    public void fireEmployee(int employeeId) throws EmployeeException {

    }

    @Override
    public boolean isPhoneNoOrEmailUnique(String phoneNo, String email, int excludeEmployeeId) throws EmployeeException {
        try (Connection conn = DatabaseConnection.provideConnection()) {
            String query = "SELECT * FROM employees WHERE (phoneNo = ? OR email = ?) AND employeeId != ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, phoneNo);
            ps.setString(2, email);
            ps.setInt(3, excludeEmployeeId);

            ResultSet rs = ps.executeQuery();
            return !rs.next(); // Eğer sonuç yoksa, benzersizdir
        } catch (Exception e) {
            throw new EmployeeException("Error while validating phone number or email uniqueness: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean updateEmployeeNonProfile(String username, String phoneNo, String email, String password) throws EmployeeException {
        return false;
    }

    @Override
    public void fireEmployee(String username) throws EmployeeException {
        try (Connection conn = DatabaseConnection.provideConnection()) {
            String query = "DELETE FROM employees WHERE username = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, username);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected == 0) {
                throw new EmployeeException("No employee found with the given username.");
            }
            System.out.println("Employee with username '" + username + "' was successfully fired.");
        } catch (Exception e) {
            throw new EmployeeException("Error while firing employee: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean isUniqueField(String field, String value) throws EmployeeException {
        String query = "SELECT * FROM employees WHERE " + field + " = ?";
        try (Connection conn = DatabaseConnection.provideConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, value);
            try (ResultSet rs = ps.executeQuery()) {
                return !rs.next(); // Kayıt bulunmazsa true döner
            }
        } catch (Exception e) {
            throw new EmployeeException("Error while checking uniqueness: " + e.getMessage(), e);
        }
    }


    @Override
    public boolean isValidDateFormat(String date) throws EmployeeException {
        try {
            java.time.LocalDate.parse(date); // Eğer tarih formatı geçersizse bir istisna fırlatılır
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}