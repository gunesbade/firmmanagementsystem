package org.example.utils;

import org.mindrot.jbcrypt.BCrypt;

/**
 * Utility class for handling password hashing and verification.
 * Provides methods for securely hashing passwords and verifying input passwords against hashed values.
 */
public class PasswordUtils {

    /**
     * Hashes a plain text password using the BCrypt algorithm.
     *
     * @param password the plain text password to be hashed
     * @return the hashed password
     */
    public static String hashPassword(String password) {
        return BCrypt.hashpw(password, BCrypt.gensalt());
    }

    /**
     * Verifies if the input password matches the hashed password stored in the database.
     *
     * @param inputPassword the plain text password entered by the user
     * @param hashedPassword the hashed password stored in the database
     * @return true if the input password matches the hashed password, false otherwise
     */
    public static boolean verifyPassword(String inputPassword, String hashedPassword) {
        return BCrypt.checkpw(inputPassword, hashedPassword);
    }
}
