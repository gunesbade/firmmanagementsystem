package org.example.entity;

import java.time.LocalDate;

public class Employee {
    private int employeeId;
    private String username;
    private String password;
    private String role;
    private String name;
    private String surname;
    private String phoneNo;
    private LocalDate dateOfBirth;
    private LocalDate dateOfStart;
    private String email;

    // Constructor
    public Employee(int employeeId, String username, String password, String role,
                    String name, String surname, String phoneNo, LocalDate dateOfBirth,
                    LocalDate dateOfStart, String email) {
        this.employeeId = employeeId;
        this.username = username;
        this.password = password;
        this.role = role;
        this.name = name;
        this.surname = surname;
        this.phoneNo = phoneNo;
        this.dateOfBirth = dateOfBirth;
        this.dateOfStart = dateOfStart;
        this.email = email;
    }

    // Getter ve Setter metodları
    public int getEmployeeId() { return employeeId; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getRole() { return role; }
    public String getName() { return name; }
    public String getSurname() { return surname; }
    public String getPhoneNo() { return phoneNo; }
    public LocalDate getDateOfBirth() { return dateOfBirth; }
    public LocalDate getDateOfStart() { return dateOfStart; }
    public String getEmail() { return email; }
}
