package org.example.menus;

import org.example.dao.EmployeeDao;
import org.example.dao.EmployeeDaoImplementation;
import org.example.entity.Employee;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;
import org.example.utils.ConsoleUtils;


/**
 * Main menu class for the Firm Management System.
 */
public class Main {

    public static void main(String[] args) {
        renderASCIIArt(); // Display the ASCII art at the top

        Scanner scanner = new Scanner(System.in);
        EmployeeDao dao = new EmployeeDaoImplementation();

        boolean isRunning = true;

        // Main menu loop
        while (isRunning) {
            ConsoleUtils.clearConsole(); // Konsolu temizle
            System.out.println("\n=== Welcome to the Firm Management System ===");
            System.out.println("1. Login");
            System.out.println("2. Exit");
            System.out.print("Choose an option: ");

            int choice = -1; // Default invalid choice
            try {
                // Get user input and parse to integer
                String input = scanner.nextLine();
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number between 1 and 2.");
                continue; // Restart the loop for valid input
            }

            switch (choice) {
                case 1 -> {
                    ConsoleUtils.clearConsole(); // Konsolu temizle
                    login(scanner, dao); // Kullanıcı giriş işlemini yap
                }
                case 2 -> {
                    System.out.println("Exiting the system...");
                    isRunning = false; // Döngüyü durdur
                }
                default -> System.out.println("Invalid option. Please enter a number between 1 and 2.");
            }
        }
    }

    /**
     * Login process for the system.
     *
     * @param scanner Scanner instance for input.
     * @param dao     Data access object for employee operations.
     */
    private static void login(Scanner scanner, EmployeeDao dao) {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        try {
            Employee emp = dao.loginEmployee(username, password);

            if (emp != null) {
                System.out.println("\nLogin Successful!");
                System.out.println("Welcome, " + emp.getName() + " " + emp.getSurname() + "!");
                System.out.println("Role: " + emp.getRole());

                // Redirect user to the appropriate menu
                if ("manager".equalsIgnoreCase(emp.getRole())) {
                    ManagerMenu.display(scanner, emp.getEmployeeId()); // Manager-specific menu
                } else {
                    RegularMenu.display(scanner, emp.getEmployeeId()); // Regular employee menu
                }
            } else {
                System.out.println("Invalid username or password.");
            }
        } catch (Exception e) {
            System.out.println("Login failed: " + e.getMessage());
        }
    }


    public static void renderASCIIArt() {
        // ANSI color codes for formatting the text
        final String RESET = "\u001B[0m";
        final String RED = "\u001B[31m";
        final String GREEN = "\u001B[32m";
        final String YELLOW = "\u001B[33m";
        final String BLUE = "\u001B[34m";
        final String MAGENTA = "\u001B[35m";
        final String CYAN = "\u001B[36m";

        // Array of names with corresponding colors for each member
        String[] names = {
                GREEN + "Zeynep Mutlu" + RESET,
                BLUE + "Güneş Bade Erdem" + RESET,
                MAGENTA + "Recep Ulaş Uzun" + RESET,
                CYAN + "Ömer Faruk Yasun" + RESET,
                YELLOW + "Yiğit Keser" + RESET
        };

        // ASCII art for the cat, with proper alignment
        String[] catArt = {
                RED + "          /\\_____/\\" + RESET,
                GREEN + "         /  o   o  \\" + RESET,
                BLUE + "        ( ==  ^  == )" + RESET,
                MAGENTA + "         )    U    (" + RESET,
                CYAN + "        /          \\" + RESET,
                YELLOW + "       /   |   |    \\" + RESET,
                RED + "      (    |   |     )" + RESET,
                GREEN + "         (_|_  |_)" + RESET
        };

        // Print out the names of the group members on the left side
        for (String name : names) {
            System.out.println(name);
        }

        // Print the cat ASCII art
        for (String line : catArt) {
            System.out.println(line);
        }
    }

}
