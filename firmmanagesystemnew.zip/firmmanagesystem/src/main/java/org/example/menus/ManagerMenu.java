package org.example.menus;

import org.example.utils.SortingAlgorithms;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class ManagerMenu {

    /**
     * Displays the Manager Menu and processes user input.
     *
     * @param scanner Scanner instance for reading user input.
     */
    public static void display(Scanner scanner) {
        boolean isRunning = true;

        while (isRunning) {
            System.out.println("\n=== Manager Menu ===");
            System.out.println("1. Update Your Profile");
            System.out.println("2. View All Employees");
            System.out.println("3. View Employees by Role");
            System.out.println("4. View Employee by Username");
            System.out.println("5. Update Employee Non-Profile Fields");
            System.out.println("6. Hire Employee");
            System.out.println("7. Fire Employee");
            System.out.println("8. Algorithms");
            System.out.println("9. Logout");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1 -> updateProfile(scanner); // Update manager profile
                case 2 -> viewAllEmployees(); // View all employees
                case 3 -> viewEmployeesByRole(scanner); // View employees by role
                case 4 -> viewEmployeeByUsername(scanner); // View employee by username
                case 5 -> updateEmployeeNonProfileFields(scanner); // Update non-profile fields
                case 6 -> hireEmployee(scanner); // Hire a new employee
                case 7 -> fireEmployee(scanner); // Fire an employee
                case 8 -> sortingAlgorithms(scanner); // Sorting algorithms comparison
                case 9 -> {
                    System.out.println("Logging out...");
                    isRunning = false;
                }
                default -> System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    /**
     * Dummy method for updating manager profile.
     *
     * @param scanner Scanner instance for reading user input.
     */
    private static void updateProfile(Scanner scanner) {
        System.out.println("\n--- Update Profile ---");
        System.out.println("This feature is under development.");
    }

    /**
     * Dummy method for viewing all employees.
     */
    private static void viewAllEmployees() {
        System.out.println("\n--- View All Employees ---");
        System.out.println("This feature is under development.");
    }

    /**
     * Dummy method for viewing employees by role.
     *
     * @param scanner Scanner instance for reading user input.
     */
    private static void viewEmployeesByRole(Scanner scanner) {
        System.out.println("\n--- View Employees by Role ---");
        System.out.println("This feature is under development.");
    }

    /**
     * Dummy method for viewing an employee by username.
     *
     * @param scanner Scanner instance for reading user input.
     */
    private static void viewEmployeeByUsername(Scanner scanner) {
        System.out.println("\n--- View Employee by Username ---");
        System.out.println("This feature is under development.");
    }

    /**
     * Dummy method for updating non-profile fields of an employee.
     *
     * @param scanner Scanner instance for reading user input.
     */
    private static void updateEmployeeNonProfileFields(Scanner scanner) {
        System.out.println("\n--- Update Employee Non-Profile Fields ---");
        System.out.println("This feature is under development.");
    }

    /**
     * Dummy method for hiring a new employee.
     *
     * @param scanner Scanner instance for reading user input.
     */
    private static void hireEmployee(Scanner scanner) {
        System.out.println("\n--- Hire Employee ---");
        System.out.println("This feature is under development.");
    }

    /**
     * Dummy method for firing an employee.
     *
     * @param scanner Scanner instance for reading user input.
     */
    private static void fireEmployee(Scanner scanner) {
        System.out.println("\n--- Fire Employee ---");
        System.out.println("This feature is under development.");
    }

    /**
     * Executes and compares multiple sorting algorithms.
     *
     * @param scanner Scanner instance for reading user input.
     */
    private static void sortingAlgorithms(Scanner scanner) {
        System.out.println("\n--- Sorting Algorithms ---");
        System.out.print("Enter dataset size (between 1,000 and 10,000): ");
        int size = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        if (size < 1000 || size > 10000) {
            System.out.println("Dataset size must be between 1,000 and 10,000.");
            return;
        }

        int[] dataset = generateRandomArray(size, -10000, 10000);
        executeAndCompareAlgorithms(dataset);
    }

    /**
     * Generates a random array with the specified size and value range.
     *
     * @param size Size of the array.
     * @param min Minimum value in the array.
     * @param max Maximum value in the array.
     * @return Randomly generated array.
     */
    private static int[] generateRandomArray(int size, int min, int max) {
        Random random = new Random();
        int[] array = new int[size];
        for (int i = 0; i < size; i++) {
            array[i] = random.nextInt(max - min + 1) + min;
        }
        return array;
    }

    /**
     * Executes and compares sorting algorithms using the SortingAlgorithms class.
     *
     * @param dataset Dataset to be sorted.
     */
    private static void executeAndCompareAlgorithms(int[] dataset) {
        int[] radixArray = Arrays.copyOf(dataset, dataset.length);
        int[] shellArray = Arrays.copyOf(dataset, dataset.length);
        int[] heapArray = Arrays.copyOf(dataset, dataset.length);
        int[] insertionArray = Arrays.copyOf(dataset, dataset.length);
        int[] javaSortArray = Arrays.copyOf(dataset, dataset.length);

        long radixTime = measureSortingTime(() -> SortingAlgorithms.radixSort(radixArray));
        long shellTime = measureSortingTime(() -> SortingAlgorithms.shellSort(shellArray));
        long heapTime = measureSortingTime(() -> SortingAlgorithms.heapSort(heapArray));
        long insertionTime = measureSortingTime(() -> SortingAlgorithms.insertionSort(insertionArray));
        long javaSortTime = measureSortingTime(() -> Arrays.sort(javaSortArray));

        System.out.println("\n--- Sorting Results ---");
        System.out.println("Radix Sort Time: " + radixTime + " ms");
        System.out.println("Shell Sort Time: " + shellTime + " ms");
        System.out.println("Heap Sort Time: " + heapTime + " ms");
        System.out.println("Insertion Sort Time: " + insertionTime + " ms");
        System.out.println("Java Arrays.sort() Time: " + javaSortTime + " ms");

        if (Arrays.equals(radixArray, javaSortArray) &&
                Arrays.equals(shellArray, javaSortArray) &&
                Arrays.equals(heapArray, javaSortArray) &&
                Arrays.equals(insertionArray, javaSortArray)) {
            System.out.println("All sorting algorithms produced identical results!");
        } else {
            System.out.println("Sorting algorithms produced different results!");
        }
    }

    /**
     * Measures the time taken to execute a sorting algorithm.
     *
     * @param sortingAlgorithm Sorting algorithm to execute.
     * @return Execution time in milliseconds.
     */
    private static long measureSortingTime(Runnable sortingAlgorithm) {
        long startTime = System.currentTimeMillis();
        sortingAlgorithm.run();
        return System.currentTimeMillis() - startTime;
    }
}
