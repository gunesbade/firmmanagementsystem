package org.example.menus;

import org.example.dao.EmployeeDao;
import org.example.dao.EmployeeDaoImplementation;
import org.example.entity.Employee;
import org.example.exception.EmployeeException;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Regular employee-specific menu class providing options to view, update profile,
 * and enforce password updates during first login.
 */
public class RegularMenu {

    /**
     * Displays the Regular Employee Menu and handles menu actions.
     *
     * @param scanner    Scanner instance for reading user input.
     * @param employeeId The ID of the logged-in employee.
     */
    public static void display(Scanner scanner, int employeeId) {
        EmployeeDao dao = new EmployeeDaoImplementation();
        boolean exit = false;

        // Check if it's the first login and enforce password update
        try {
            Employee emp = dao.getProfile(employeeId);
            if ("Default123!".equals(emp.getPassword())) { // Check if the password is still default
                System.out.println("You must update your default password on your first login.");
                while (true) {
                    System.out.print("Enter your new secure password (minimum 8 characters, one uppercase letter, one number, and one symbol): ");
                    String newPassword = scanner.nextLine();
                    if (newPassword.matches("^(?=.[a-z])(?=.[A-Z])(?=.\\d)(?=.[@$!%?&])[A-Za-z\\d@$!%?&]{8,}$")) {
                        dao.updateProfile(employeeId, emp.getPhoneNo(), emp.getEmail(), newPassword);
                        System.out.println("Password updated successfully! Please log in again.");
                        return; // Logout after password update
                    } else {
                        System.out.println("Password must be at least 8 characters long, contain an uppercase letter, a number, and a symbol.");
                    }
                }
            }
        } catch (EmployeeException e) {
            System.out.println("Error: " + e.getMessage());
            return;
        }

        // Main menu loop
        while (!exit) {
            try {
                System.out.println("\n--- Regular Employee Menu ---");
                System.out.println("1. Display Profile");
                System.out.println("2. Update Profile");
                System.out.println("3. Logout");
                System.out.print("Choose an option: ");

                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline character

                switch (choice) {
                    case 1 -> displayProfile(dao, employeeId);
                    case 2 -> updateProfile(scanner, dao, employeeId);
                    case 3 -> {
                        System.out.println("Logging out...");
                        exit = true;
                    }
                    default -> System.out.println("Invalid choice! Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid menu option.");
                scanner.nextLine(); // Clear the invalid input
            }
        }
    }

    /**
     * Displays the non-profile fields of the employee.
     *
     * @param dao        DAO instance for accessing employee data.
     * @param employeeId The ID of the logged-in employee.
     */
    private static void displayProfile(EmployeeDao dao, int employeeId) {
        try {
            Employee emp = dao.getProfile(employeeId);
            if (emp != null) {
                System.out.println("\n--- Profile Information (Non-Profile Fields) ---");
                System.out.println("Name: " + emp.getName());
                System.out.println("Surname: " + emp.getSurname());
                System.out.println("Username: " + emp.getUsername());
                System.out.println("Role: " + emp.getRole());
                System.out.println("Date of Birth: " + emp.getDateOfBirth());
                System.out.println("Date of Start: " + emp.getDateOfStart());
            } else {
                System.out.println("Profile not found.");
            }
        } catch (Exception e) {
            System.out.println("Error fetching profile: " + e.getMessage());
        }
    }

    /**
     * Updates the profile of the logged-in employee.
     *
     * @param scanner    Scanner instance for reading user input.
     * @param dao        DAO instance for accessing employee data.
     * @param employeeId The ID of the logged-in employee.
     */
    private static void updateProfile(Scanner scanner, EmployeeDao dao, int employeeId) {
        System.out.println("\n--- Update Profile ---");

        Employee currentProfile;
        try {
            currentProfile = dao.getProfile(employeeId);
            if (currentProfile == null) {
                System.out.println("Profile not found.");
                return;
            }
        } catch (EmployeeException e) {
            System.out.println("Error fetching current profile: " + e.getMessage());
            return;
        }

        String phoneNo;
        while (true) {
            System.out.print("Enter new phone number (format: 5XX XXX XX XX, or press Enter to keep current): ");
            phoneNo = scanner.nextLine();
            if (phoneNo.isEmpty()) {
                phoneNo = currentProfile.getPhoneNo(); // Keep existing value
                break;
            }
            if (phoneNo.matches("5\\d{2} \\d{3} \\d{2} \\d{2}")) break; // Format validation
            System.out.println("Invalid phone number format. Please use '5XX XXX XX XX' format.");
        }

        String email;
        while (true) {
            System.out.print("Enter new email (must contain '@' and '.', with valid text between them, or press Enter to keep current): ");
            email = scanner.nextLine();
            if (email.isEmpty()) {
                email = currentProfile.getEmail(); // Keep existing value
                break;
            }
            // Validate format
            if (email.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$")) {
                break;
            }
            System.out.println("Invalid email format. Ensure it has '@' and '.', with valid text before and between them (e.g., example@domain.com).");
        }

        String password;
        while (true) {
            System.out.print("Enter new password (must contain at least 8 characters, one uppercase letter, one number, and one symbol, or press Enter to keep current): ");
            password = scanner.nextLine();
            if (password.isEmpty()) {
                password = currentProfile.getPassword(); // Keep existing password
                break;
            }
            if (password.matches("^(?=.[a-z])(?=.[A-Z])(?=.\\d)(?=.[@$!%?&])[A-Za-z\\d@$!%?&]{8,}$")) break; // Password rules
            System.out.println("Password must be at least 8 characters long, contain an uppercase letter, a number, and a symbol.");
        }

        // Check if no updates were made
        if (phoneNo.equals(currentProfile.getPhoneNo()) &&
                email.equals(currentProfile.getEmail()) &&
                password.equals(currentProfile.getPassword())) {
            System.out.println("No updates were made. Existing values were kept.");
            return;
        }

        try {
            dao.updateProfile(employeeId, phoneNo, email, password);
            System.out.println("Profile updated successfully!");
        } catch (EmployeeException e) {
            System.out.println("Error updating profile: " + e.getMessage());
        }
    }
}