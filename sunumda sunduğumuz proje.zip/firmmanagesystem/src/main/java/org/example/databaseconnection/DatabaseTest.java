import java.sql.Connection;
import org.example.databaseconnection.DatabaseConnection;

/**
 * Test class for verifying database connection.
 * This class attempts to establish a connection to the database and prints the result.
 */
public class DatabaseTest {

    /**
     * Main method to test the database connection.
     *
     * @param args Command-line arguments (not used).
     */
    public static void main(String[] args) {
        // Attempt to get a database connection
        Connection conn = DatabaseConnection.provideConnection();

        // Check if the connection was successful
        if (conn != null) {
            System.out.println("Database connection successful!");
        } else {
            System.out.println("Database connection failed!");
        }
    }
}