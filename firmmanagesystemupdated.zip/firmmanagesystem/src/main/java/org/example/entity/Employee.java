package org.example.entity;

import java.time.LocalDate;

public class Employee {
    private int employeeId;
    private String username;
    private String password;
    private String role;  // manager, engineer, technician, intern
    private String name;
    private String surname;
    private String phoneNo;
    private LocalDate dateOfBirth;
    private LocalDate dateOfStart;
    private String email;

    // Constructor
    public Employee(int employeeId, String username, String password, String role,
                    String name, String surname, String phoneNo, LocalDate dateOfBirth,
                    LocalDate dateOfStart, String email) {
        this.employeeId = employeeId;
        this.username = username;
        this.password = password;
        this.role = role;
        this.name = name;
        this.surname = surname;
        this.phoneNo = phoneNo;
        this.dateOfBirth = dateOfBirth;
        this.dateOfStart = dateOfStart;
        this.email = email;
    }

    // Getters and Setters
    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public LocalDate getDateOfStart() {
        return dateOfStart;
    }

    public void setDateOfStart(LocalDate dateOfStart) {
        this.dateOfStart = dateOfStart;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "Employee {" +
                "ID=" + employeeId +
                ", Username='" + username + '\'' +
                ", Role='" + role + '\'' +
                ", Name='" + name + '\'' +
                ", Surname='" + surname + '\'' +
                ", Phone='" + phoneNo + '\'' +
                ", Email='" + email + '\'' +
                ", Date of Birth=" + dateOfBirth +
                ", Start Date=" + dateOfStart +
                '}';
    }
}
