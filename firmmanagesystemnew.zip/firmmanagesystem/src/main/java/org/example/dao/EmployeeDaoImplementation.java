package org.example.dao;

import org.example.databaseconnection.DatabaseConnection;
import org.example.entity.Employee;
import org.example.exception.EmployeeException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of the EmployeeDao interface.
 */
public class EmployeeDaoImplementation implements EmployeeDao {

    @Override
    public Employee loginEmployee(String username, String password) throws EmployeeException {
        Employee emp = null;

        try (Connection conn = DatabaseConnection.provideConnection()) {
            String query = "SELECT * FROM employees WHERE username = ? AND password = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                emp = new Employee(
                        rs.getInt("employeeId"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role"),
                        rs.getString("name"),
                        rs.getString("surname"),
                        rs.getString("phoneNo"),
                        rs.getDate("dateOfBirth") != null ? rs.getDate("dateOfBirth").toLocalDate() : null,
                        rs.getDate("dateOfStart") != null ? rs.getDate("dateOfStart").toLocalDate() : null,
                        rs.getString("email")
                );
            } else {
                throw new EmployeeException("Invalid username or password.");
            }
        } catch (Exception e) {
            throw new EmployeeException("Database error: " + e.getMessage(), e);
        }

        return emp;
    }

    @Override
    public Employee getProfile(int employeeId) throws EmployeeException {
        Employee emp = null;

        try (Connection conn = DatabaseConnection.provideConnection()) {
            String query = "SELECT * FROM employees WHERE employeeId = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, employeeId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                emp = new Employee(
                        rs.getInt("employeeId"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role"),
                        rs.getString("name"),
                        rs.getString("surname"),
                        rs.getString("phoneNo"),
                        rs.getDate("dateOfBirth") != null ? rs.getDate("dateOfBirth").toLocalDate() : null,
                        rs.getDate("dateOfStart") != null ? rs.getDate("dateOfStart").toLocalDate() : null,
                        rs.getString("email")
                );
            } else {
                throw new EmployeeException("Employee not found.");
            }
        } catch (Exception e) {
            throw new EmployeeException("Database error: " + e.getMessage(), e);
        }

        return emp;
    }

    @Override
    public void updateProfile(int employeeId, String phoneNo, String email, String password) throws EmployeeException {
        try (Connection conn = DatabaseConnection.provideConnection()) {
            String query = "UPDATE employees SET phoneNo = ?, email = ?, password = ? WHERE employeeId = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, phoneNo);
            ps.setString(2, email);
            ps.setString(3, password);
            ps.setInt(4, employeeId);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected == 0) {
                throw new EmployeeException("Update failed. Employee not found.");
            }
        } catch (Exception e) {
            throw new EmployeeException("Database error: " + e.getMessage(), e);
        }
    }

    @Override
    public List<Employee> getAllEmployees() throws EmployeeException {
        List<Employee> employees = new ArrayList<>();

        try (Connection conn = DatabaseConnection.provideConnection()) {
            String query = "SELECT * FROM employees";
            PreparedStatement ps = conn.prepareStatement(query);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Employee emp = new Employee(
                        rs.getInt("employeeId"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role"),
                        rs.getString("name"),
                        rs.getString("surname"),
                        rs.getString("phoneNo"),
                        rs.getDate("dateOfBirth") != null ? rs.getDate("dateOfBirth").toLocalDate() : null,
                        rs.getDate("dateOfStart") != null ? rs.getDate("dateOfStart").toLocalDate() : null,
                        rs.getString("email")
                );
                employees.add(emp);
            }
        } catch (Exception e) {
            throw new EmployeeException("Database error: " + e.getMessage(), e);
        }

        return employees;
    }

    @Override
    public List<Employee> getEmployeesByRole(String role) throws EmployeeException {
        List<Employee> employees = new ArrayList<>();

        try (Connection conn = DatabaseConnection.provideConnection()) {
            String query = "SELECT * FROM employees WHERE role = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, role);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Employee emp = new Employee(
                        rs.getInt("employeeId"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role"),
                        rs.getString("name"),
                        rs.getString("surname"),
                        rs.getString("phoneNo"),
                        rs.getDate("dateOfBirth") != null ? rs.getDate("dateOfBirth").toLocalDate() : null,
                        rs.getDate("dateOfStart") != null ? rs.getDate("dateOfStart").toLocalDate() : null,
                        rs.getString("email")
                );
                employees.add(emp);
            }
        } catch (Exception e) {
            throw new EmployeeException("Database error: " + e.getMessage(), e);
        }

        return employees;
    }

    @Override
    public Employee getEmployeeByUsername(String username) throws EmployeeException {
        return null;
    }

    @Override
    public void updateEmployeeNonProfile(String username, String phoneNo, String email) throws EmployeeException {
        try (Connection conn = DatabaseConnection.provideConnection()) {
            String query = "UPDATE employees SET phoneNo = ?, email = ? WHERE username = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, phoneNo);
            ps.setString(2, email);
            ps.setString(3, username);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected == 0) {
                throw new EmployeeException("Update failed. Employee not found.");
            }
        } catch (Exception e) {
            throw new EmployeeException("Database error: " + e.getMessage(), e);
        }
    }

    @Override
    public void hireEmployee(Employee employee) throws EmployeeException {
        try (Connection conn = DatabaseConnection.provideConnection()) {
            String query = "INSERT INTO employees (username, password, role, name, surname, phoneNo, dateOfBirth, dateOfStart, email) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(query);

            ps.setString(1, employee.getUsername());
            ps.setString(2, employee.getPassword());
            ps.setString(3, employee.getRole());
            ps.setString(4, employee.getName());
            ps.setString(5, employee.getSurname());
            ps.setString(6, employee.getPhoneNo());
            ps.setDate(7, employee.getDateOfBirth() != null ? java.sql.Date.valueOf(employee.getDateOfBirth()) : null);
            ps.setDate(8, employee.getDateOfStart() != null ? java.sql.Date.valueOf(employee.getDateOfStart()) : null);
            ps.setString(9, employee.getEmail());

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected == 0) {
                throw new EmployeeException("Failed to hire employee.");
            }
        } catch (Exception e) {
            throw new EmployeeException("Database error: " + e.getMessage(), e);
        }
    }

    @Override
    public void fireEmployee(int employeeId) throws EmployeeException {
        try (Connection conn = DatabaseConnection.provideConnection()) {
            String query = "DELETE FROM employees WHERE employeeId = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, employeeId);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected == 0) {
                throw new EmployeeException("Failed to fire employee. Employee not found.");
            }
        } catch (Exception e) {
            throw new EmployeeException("Database error: " + e.getMessage(), e);
        }
    }

    @Override
    public void fireEmployee(String username) throws EmployeeException {
        try (Connection conn = DatabaseConnection.provideConnection()) {
            String query = "DELETE FROM employees WHERE username = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, username);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected == 0) {
                throw new EmployeeException("No employee found with the username: " + username);
            }
        } catch (Exception e) {
            throw new EmployeeException("Failed to fire employee: " + e.getMessage(), e);
        }
    }
}
