package org.example.databaseconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Utility class for managing database connections.
 * Provides a method to establish a connection with the database.
 */
public class DatabaseConnection {

    // Database URL
    private static final String URL = "jdbc:mysql://localhost:3306/firmmanagesystem";
    // Database username
    private static final String USER = "root";
    // Database password
    private static final String PASSWORD = "$Bade1907";

    /**
     * Establishes a connection to the database.
     *
     * @return a {@link Connection} object if the connection is successful, otherwise {@code null}
     */
    public static Connection provideConnection() {
        Connection conn = null;

        try {
            // Attempt to establish a connection
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            // Print error message and stack trace if the connection fails
            System.out.println("Database connection failed: " + e.getMessage());
            e.printStackTrace();
        }

        return conn;
    }
}