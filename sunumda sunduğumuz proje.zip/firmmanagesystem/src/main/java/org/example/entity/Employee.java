package org.example.entity;

import java.time.LocalDate;

/**
 * Represents an employee in the system with details such as ID, username, role,
 * personal information, and employment dates.
 */
public class Employee {
    private int employeeId;
    private String username;
    private String password;
    private String role; // manager, engineer, technician, intern
    private String name;
    private String surname;
    private String phoneNo;
    private LocalDate dateOfBirth;
    private LocalDate dateOfStart;
    private String email;

    /**
     * Constructs an {@code Employee} object with the specified attributes.
     *
     * @param employeeId  the unique identifier for the employee
     * @param username    the username used for system login
     * @param password    the password used for system login
     * @param role        the role of the employee (e.g., manager, engineer)
     * @param name        the first name of the employee
     * @param surname     the last name of the employee
     * @param phoneNo     the phone number of the employee
     * @param dateOfBirth the date of birth of the employee
     * @param dateOfStart the start date of the employee in the company
     * @param email       the email address of the employee
     */
    public Employee(int employeeId, String username, String password, String role,
                    String name, String surname, String phoneNo, LocalDate dateOfBirth,
                    LocalDate dateOfStart, String email) {
        this.employeeId = employeeId;
        this.username = username;
        this.password = password;
        this.role = role;
        this.name = name;
        this.surname = surname;
        this.phoneNo = phoneNo;
        this.dateOfBirth = dateOfBirth;
        this.dateOfStart = dateOfStart;
        this.email = email;
    }

    /**
     * Gets the employee's unique identifier.
     *
     * @return the employee ID
     */
    public int getEmployeeId() {
        return employeeId;
    }

    /**
     * Sets the employee's unique identifier.
     *
     * @param employeeId the new employee ID
     */
    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    /**
     * Gets the employee's username.
     *
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets the employee's username.
     *
     * @param username the new username
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Gets the employee's password.
     *
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the employee's password.
     *
     * @param password the new password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Gets the employee's role.
     *
     * @return the role
     */
    public String getRole() {
        return role;
    }

    /**
     * Sets the employee's role.
     *
     * @param role the new role
     */
    public void setRole(String role) {
        this.role = role;
    }

    /**
     * Gets the employee's first name.
     *
     * @return the first name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the employee's first name.
     *
     * @param name the new first name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the employee's last name.
     *
     * @return the last name
     */
    public String getSurname() {
        return surname;
    }

    /**
     * Sets the employee's last name.
     *
     * @param surname the new last name
     */
    public void setSurname(String surname) {
        this.surname = surname;
    }

    /**
     * Gets the employee's phone number.
     *
     * @return the phone number
     */
    public String getPhoneNo() {
        return phoneNo;
    }

    /**
     * Sets the employee's phone number.
     *
     * @param phoneNo the new phone number
     */
    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    /**
     * Gets the employee's date of birth.
     *
     * @return the date of birth
     */
    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * Sets the employee's date of birth.
     *
     * @param dateOfBirth the new date of birth
     */
    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    /**
     * Gets the employee's start date in the company.
     *
     * @return the start date
     */
    public LocalDate getDateOfStart() {
        return dateOfStart;
    }

    /**
     * Sets the employee's start date in the company.
     *
     * @param dateOfStart the new start date
     */
    public void setDateOfStart(LocalDate dateOfStart) {
        this.dateOfStart = dateOfStart;
    }

    /**
     * Gets the employee's email address.
     *
     * @return the email address
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the employee's email address.
     *
     * @param email the new email address
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Returns a string representation of the employee.
     *
     * @return a string containing the employee's details
     */
    @Override
    public String toString() {
        return "Employee {" +
                "ID=" + employeeId +
                ", Username='" + username + '\'' +
                ", Role='" + role + '\'' +
                ", Name='" + name + '\'' +
                ", Surname='" + surname + '\'' +
                ", Phone='" + phoneNo + '\'' +
                ", Email='" + email + '\'' +
                ", Date of Birth=" + dateOfBirth +
                ", Start Date=" + dateOfStart +
                '}';
    }
}