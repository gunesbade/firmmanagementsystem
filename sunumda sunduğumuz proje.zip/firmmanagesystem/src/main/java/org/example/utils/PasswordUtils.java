package org.example.utils;

import org.mindrot.jbcrypt.BCrypt;

/**
 * Utility class for handling password hashing and verification.
 * <p>
 * This class leverages the BCrypt algorithm to securely hash passwords and verify plain text passwords against stored hashed values.
 * The BCrypt algorithm is a reliable method for password storage as it incorporates a salt to protect against rainbow table attacks
 * and is computationally expensive to mitigate brute force attacks.
 */
public class PasswordUtils {

    /**
     * Hashes a plain text password using the BCrypt algorithm.
     * <p>
     * This method generates a cryptographically secure hash for the provided password.
     * It includes a randomly generated salt, ensuring that the same password produces different hashes.
     *
     * @param password the plain text password to be hashed
     * @return the hashed password as a String
     */
    public static String hashPassword(String password) {
        // Hash the password using BCrypt and a randomly generated salt
        return BCrypt.hashpw(password, BCrypt.gensalt());
    }

    /**
     * Verifies if the input password matches the hashed password stored in the database.
     * <p>
     * This method compares a plain text password with a stored hashed password to determine if they match.
     * It uses BCrypt's built-in functionality to perform a secure comparison, avoiding timing attacks.
     *
     * @param inputPassword the plain text password entered by the user
     * @param hashedPassword the hashed password retrieved from the database
     * @return true if the input password matches the hashed password, false otherwise
     */
    public static boolean verifyPassword(String inputPassword, String hashedPassword) {
        // Verify the plain text password against the hashed password
        return BCrypt.checkpw(inputPassword, hashedPassword);
    }
}