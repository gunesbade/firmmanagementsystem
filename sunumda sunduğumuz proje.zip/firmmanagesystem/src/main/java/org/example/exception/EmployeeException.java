package org.example.exception;

/**
 * Custom exception class for handling employee-related errors in the system.
 * This class extends {@link Exception} and provides constructors for creating
 * exceptions with custom messages and causes.
 */
public class EmployeeException extends Exception {

    /**
     * Constructs a new {@code EmployeeException} with the specified detail message.
     *
     * @param message the detail message (which is saved for later retrieval by the {@link #getMessage()} method)
     */
    public EmployeeException(String message) {
        super(message);
    }

    /**
     * Constructs a new {@code EmployeeException} with the specified detail message and cause.
     *
     * @param message the detail message (which is saved for later retrieval by the {@link #getMessage()} method)
     * @param cause   the cause (which is saved for later retrieval by the {@link #getCause()} method).
     *                A {@code null} value is permitted, and indicates that the cause is nonexistent or unknown.
     */
    public EmployeeException(String message, Throwable cause) {
        super(message, cause);
    }
}